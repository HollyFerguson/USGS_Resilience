See the [examples](examples) directory as a starting point for command-line use of `nshmp-haz`.

[Matlab](matlab) shows how to take advantage of the ground motion model implementations in `nshmp-haz`.

[Nshm](nshm) contains site lists and map polygons commonly used by the USGS NSHMP.

[Peer](peer) is a collection of simple source models that are used for testing.
