Using nshmp-haz with Matlab
---------------------------

All recent versions of Matlab include a Java runtime environment and it is therefore relatively straightforward to use the nshmp-haz library.

#### Requirements

1.  Matlab R2013B or higher (nshmp-haz targets Java 7; prior versions of Matlab use Java 6).
2.  A [build](https://github.com/usgs/nshmp-haz/wiki/Building-&-Running) of nshmp-haz.
