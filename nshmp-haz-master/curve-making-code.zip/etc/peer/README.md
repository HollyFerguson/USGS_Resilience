#### PEER Test Cases

The PEER PSHA validation project developed a number of source models for the purpose of examining the sensitivity of seismic hazard to different PSHA implementations (codes). These test cases are used as end-to-end unit tests in `nshmp-haz`. 

For more information, including source model specifications, result tables, and summary reports, please see the [PEER](http://peer.berkeley.edu) PSHA validation project (TODO: link; no site as yet).
