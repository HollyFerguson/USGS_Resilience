## NSHMP Conterminous U.S. 2008
**NOTE: This model is preliminary and for review purposes only. It is intended for use with an updated USGS earthquake hazards codebase: [nshmp-haz](https://github.com/usgs/nshmp-haz). It is currently under review and does NOT represent an official release or product. For official release products please see the [USGS Earthquake Hazards](http://earthquake.usgs.gov/hazards/) website.**

For details on the format of this hazard model, see the [nshmp-haz wiki](https://github.com/usgs/nshmp-haz/wiki).

See also the [2008 USGS Earthquake Hazard Maps & Data](http://earthquake.usgs.gov/hazards/products/conterminous/).
