
Unsegmented a-faults are separated out as they rupture their
full down-dip width and float only along-strike, compared to
all other WUS fault sources that follow the NSHM rupture
floating model.
